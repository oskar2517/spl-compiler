const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(346, 110, 280, 131, 16711680);
    await drawLine(280, 131, 250, 164, 16727296);
    await drawLine(250, 164, 245, 188, 16742912);
    await drawLine(245, 188, 256, 246, 16758784);
    await drawLine(256, 246, 299, 279, 16774400);
    await drawLine(299, 279, 378, 283, 13434624);
    await drawLine(378, 283, 404, 270, 9436928);
    await drawLine(404, 270, 417, 248, 5439232);
    await drawLine(417, 248, 419, 199, 1376000);
    await drawLine(419, 199, 422, 196, 65321);
    await drawLine(422, 196, 432, 195, 65382);
    await drawLine(432, 195, 426, 193, 65443);
    await drawLine(426, 193, 430, 192, 65504);
    await drawLine(430, 192, 425, 191, 57599);
    await drawLine(425, 191, 427, 191, 41983);
    await drawLine(427, 191, 447, 190, 26367);
    await drawLine(447, 190, 451, 188, 10751);
    await drawLine(451, 188, 449, 184, 1310975);
    await drawLine(449, 184, 434, 182, 5374207);
    await drawLine(434, 182, 424, 182, 9371903);
    await drawLine(424, 182, 419, 182, 13369599);
    await drawLine(419, 182, 416, 179, 16711925);
    await drawLine(416, 179, 399, 132, 16711864);
    await drawLine(399, 132, 376, 114, 16711802);
    await drawLine(376, 114, 352, 109, 16711741);
}

main();
