const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(332, 151, 308, 159, 16711680);
    await drawLine(308, 159, 272, 224, 16741888);
    await drawLine(272, 224, 286, 301, 16771840);
    await drawLine(286, 301, 302, 320, 10354432);
    await drawLine(302, 320, 359, 333, 2621184);
    await drawLine(359, 333, 426, 314, 65358);
    await drawLine(426, 314, 456, 282, 65476);
    await drawLine(456, 282, 461, 257, 50431);
    await drawLine(461, 257, 458, 233, 20223);
    await drawLine(458, 233, 459, 208, 2556159);
    await drawLine(459, 208, 440, 180, 10289407);
    await drawLine(440, 180, 386, 154, 16711915);
    await drawLine(386, 154, 342, 150, 16711798);
}

main();
