const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(330, 146, 293, 170, 16711680);
    await drawLine(293, 170, 289, 169, 16734720);
    await drawLine(289, 169, 284, 170, 16757760);
    await drawLine(284, 170, 276, 164, 15793920);
    await drawLine(276, 164, 272, 164, 9895680);
    await drawLine(272, 164, 271, 168, 3997440);
    await drawLine(271, 168, 281, 179, 65310);
    await drawLine(281, 179, 264, 209, 65400);
    await drawLine(264, 209, 266, 249, 65490);
    await drawLine(266, 249, 286, 277, 54015);
    await drawLine(286, 277, 340, 300, 30975);
    await drawLine(340, 300, 355, 300, 7935);
    await drawLine(355, 300, 389, 271, 3932415);
    await drawLine(389, 271, 411, 245, 9830655);
    await drawLine(411, 245, 393, 179, 15728895);
    await drawLine(393, 179, 366, 151, 16711860);
    await drawLine(366, 151, 337, 145, 16711770);
}

main();
