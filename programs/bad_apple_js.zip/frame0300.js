const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(303, 64, 264, 94, 16711680);
    await drawLine(264, 94, 249, 135, 16744448);
    await drawLine(249, 135, 253, 165, 16776960);
    await drawLine(253, 165, 260, 178, 8453888);
    await drawLine(260, 178, 292, 202, 65280);
    await drawLine(292, 202, 311, 206, 65408);
    await drawLine(311, 206, 361, 185, 65535);
    await drawLine(361, 185, 385, 154, 32767);
    await drawLine(385, 154, 387, 129, 255);
    await drawLine(387, 129, 372, 87, 8323327);
    await drawLine(372, 87, 352, 72, 16711935);
    await drawLine(352, 72, 314, 61, 16711808);
}

main();
