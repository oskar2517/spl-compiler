const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(0, 240, 0, 480, 16711680);
    await drawLine(0, 480, 640, 480, 16760576);
    await drawLine(640, 480, 640, 0, 8453888);
    await drawLine(640, 0, 495, -(1), 65344);
    await drawLine(495, -(1), 490, 0, 65535);
    await drawLine(490, 0, 175, -(1), 16639);
    await drawLine(175, -(1), 170, 0, 8323327);
    await drawLine(170, 0, 0, 0, 16711871);
}

main();
