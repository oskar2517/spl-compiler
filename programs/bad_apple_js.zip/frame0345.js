const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(359, 164, 325, 174, 16711680);
    await drawLine(325, 174, 280, 244, 16734720);
    await drawLine(280, 244, 278, 289, 16757760);
    await drawLine(278, 289, 299, 328, 15793920);
    await drawLine(299, 328, 348, 351, 9895680);
    await drawLine(348, 351, 351, 354, 3997440);
    await drawLine(351, 354, 356, 356, 65310);
    await drawLine(356, 356, 360, 354, 65400);
    await drawLine(360, 354, 364, 353, 65490);
    await drawLine(364, 353, 399, 355, 54015);
    await drawLine(399, 355, 453, 313, 30975);
    await drawLine(453, 313, 461, 230, 7935);
    await drawLine(461, 230, 447, 193, 3932415);
    await drawLine(447, 193, 423, 176, 9830655);
    await drawLine(423, 176, 404, 173, 15728895);
    await drawLine(404, 173, 376, 162, 16711860);
    await drawLine(376, 162, 371, 162, 16711770);
}

main();
