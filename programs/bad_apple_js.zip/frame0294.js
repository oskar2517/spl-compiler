const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(227, 1, 246, 23, 16711680);
    await drawLine(246, 23, 285, 28, 8453888);
    await drawLine(285, 28, 319, 0, 65535);
    await drawLine(319, 0, 275, 0, 8323327);
}

main();
