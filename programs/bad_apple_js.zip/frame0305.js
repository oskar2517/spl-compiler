const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(336, 158, 313, 166, 16711680);
    await drawLine(313, 166, 286, 201, 16731392);
    await drawLine(286, 201, 281, 202, 16750848);
    await drawLine(281, 202, 263, 193, 16770304);
    await drawLine(263, 193, 260, 195, 13434624);
    await drawLine(260, 195, 261, 200, 8453888);
    await drawLine(261, 200, 279, 209, 3407616);
    await drawLine(279, 209, 279, 213, 65305);
    await drawLine(279, 213, 267, 234, 65382);
    await drawLine(267, 234, 269, 268, 65459);
    await drawLine(269, 268, 286, 293, 65535);
    await drawLine(286, 293, 347, 312, 45823);
    await drawLine(347, 312, 372, 310, 26367);
    await drawLine(372, 310, 402, 284, 6655);
    await drawLine(402, 284, 411, 256, 3342591);
    await drawLine(411, 256, 414, 252, 8323327);
    await drawLine(414, 252, 418, 238, 13369599);
    await drawLine(418, 238, 387, 182, 16711910);
    await drawLine(387, 182, 346, 157, 16711833);
    await drawLine(346, 157, 341, 157, 16711756);
}

main();
