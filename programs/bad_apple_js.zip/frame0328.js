const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(327, 109, 309, 118, 16711680);
    await drawLine(309, 118, 281, 125, 16726784);
    await drawLine(281, 125, 266, 138, 16741888);
    await drawLine(266, 138, 252, 221, 16756992);
    await drawLine(252, 221, 263, 259, 16771840);
    await drawLine(263, 259, 286, 278, 14221056);
    await drawLine(286, 278, 320, 280, 10354432);
    await drawLine(320, 280, 344, 274, 6487808);
    await drawLine(344, 274, 348, 275, 2621184);
    await drawLine(348, 275, 350, 289, 65300);
    await drawLine(350, 289, 351, 275, 65358);
    await drawLine(351, 275, 353, 276, 65417);
    await drawLine(353, 276, 358, 300, 65476);
    await drawLine(358, 300, 356, 303, 65535);
    await drawLine(356, 303, 361, 304, 50431);
    await drawLine(361, 304, 365, 302, 35327);
    await drawLine(365, 302, 366, 297, 20223);
    await drawLine(366, 297, 361, 272, 5375);
    await drawLine(361, 272, 363, 269, 2556159);
    await drawLine(363, 269, 400, 256, 6422783);
    await drawLine(400, 256, 419, 232, 10289407);
    await drawLine(419, 232, 424, 203, 14156031);
    await drawLine(424, 203, 397, 140, 16711915);
    await drawLine(397, 140, 357, 110, 16711857);
    await drawLine(357, 110, 343, 106, 16711798);
    await drawLine(343, 106, 328, 108, 16711739);
}

main();
