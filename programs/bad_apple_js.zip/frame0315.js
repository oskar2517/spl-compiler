const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(357, 255, 297, 279, 16711680);
    await drawLine(297, 279, 271, 315, 16732416);
    await drawLine(271, 315, 270, 339, 16752896);
    await drawLine(270, 339, 279, 357, 16773632);
    await drawLine(279, 357, 281, 382, 12386048);
    await drawLine(281, 382, 296, 401, 7077632);
    await drawLine(296, 401, 368, 417, 1834752);
    await drawLine(368, 417, 410, 403, 65334);
    await drawLine(410, 403, 426, 385, 65414);
    await drawLine(426, 385, 430, 320, 65495);
    await drawLine(430, 320, 434, 319, 55295);
    await drawLine(434, 319, 439, 319, 34559);
    await drawLine(439, 319, 443, 317, 14079);
    await drawLine(443, 317, 440, 314, 1769727);
    await drawLine(440, 314, 435, 312, 7012607);
    await drawLine(435, 312, 426, 313, 12321023);
    await drawLine(426, 313, 407, 272, 16711922);
    await drawLine(407, 272, 387, 257, 16711841);
    await drawLine(387, 257, 367, 254, 16711761);
}

main();
