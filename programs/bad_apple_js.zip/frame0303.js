const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(332, 130, 304, 141, 16711680);
    await drawLine(304, 141, 299, 141, 16733440);
    await drawLine(299, 141, 289, 140, 16755200);
    await drawLine(289, 140, 286, 143, 16776960);
    await drawLine(286, 143, 288, 147, 11206400);
    await drawLine(288, 147, 269, 166, 5635840);
    await drawLine(269, 166, 258, 209, 65280);
    await drawLine(258, 209, 269, 242, 65365);
    await drawLine(269, 242, 319, 282, 65450);
    await drawLine(319, 282, 333, 286, 65535);
    await drawLine(333, 286, 347, 282, 43775);
    await drawLine(347, 282, 360, 273, 22015);
    await drawLine(360, 273, 369, 271, 255);
    await drawLine(369, 271, 403, 241, 5570815);
    await drawLine(403, 241, 395, 173, 11141375);
    await drawLine(395, 173, 373, 140, 16711935);
    await drawLine(373, 140, 346, 130, 16711850);
    await drawLine(346, 130, 336, 129, 16711765);
}

main();
