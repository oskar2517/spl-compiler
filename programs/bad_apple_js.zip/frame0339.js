const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(343, 136, 288, 177, 16711680);
    await drawLine(288, 177, 281, 172, 16737792);
    await drawLine(281, 172, 278, 176, 16763904);
    await drawLine(278, 176, 282, 185, 13434624);
    await drawLine(282, 185, 281, 190, 6749952);
    await drawLine(281, 190, 263, 247, 65280);
    await drawLine(263, 247, 271, 275, 65382);
    await drawLine(271, 275, 326, 317, 65484);
    await drawLine(326, 317, 390, 325, 52479);
    await drawLine(390, 325, 428, 302, 26367);
    await drawLine(428, 302, 458, 246, 255);
    await drawLine(458, 246, 458, 221, 6684927);
    await drawLine(458, 221, 403, 151, 13369599);
    await drawLine(403, 151, 362, 134, 16711884);
    await drawLine(362, 134, 357, 133, 16711782);
}

main();
