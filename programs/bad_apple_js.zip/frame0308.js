const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(350, 211, 312, 220, 16711680);
    await drawLine(312, 220, 277, 248, 16733440);
    await drawLine(277, 248, 270, 261, 16755200);
    await drawLine(270, 261, 279, 319, 16776960);
    await drawLine(279, 319, 289, 330, 11206400);
    await drawLine(289, 330, 291, 335, 5635840);
    await drawLine(291, 335, 278, 342, 65280);
    await drawLine(278, 342, 275, 346, 65365);
    await drawLine(275, 346, 278, 349, 65450);
    await drawLine(278, 349, 296, 339, 65535);
    await drawLine(296, 339, 299, 339, 43775);
    await drawLine(299, 339, 315, 358, 22015);
    await drawLine(315, 358, 359, 367, 255);
    await drawLine(359, 367, 394, 350, 5570815);
    await drawLine(394, 350, 425, 299, 11141375);
    await drawLine(425, 299, 427, 265, 16711935);
    await drawLine(427, 265, 391, 218, 16711850);
    await drawLine(391, 218, 358, 210, 16711765);
}

main();
