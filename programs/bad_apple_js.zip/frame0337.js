const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(332, 113, 329, 142, 16711680);
    await drawLine(329, 142, 274, 163, 16731392);
    await drawLine(274, 163, 265, 175, 16750848);
    await drawLine(265, 175, 262, 233, 16770304);
    await drawLine(262, 233, 304, 301, 13434624);
    await drawLine(304, 301, 330, 315, 8453888);
    await drawLine(330, 315, 350, 313, 3407616);
    await drawLine(350, 313, 362, 306, 65305);
    await drawLine(362, 306, 397, 303, 65382);
    await drawLine(397, 303, 429, 279, 65459);
    await drawLine(429, 279, 439, 187, 65535);
    await drawLine(439, 187, 426, 154, 45823);
    await drawLine(426, 154, 402, 137, 26367);
    await drawLine(402, 137, 383, 134, 6655);
    await drawLine(383, 134, 343, 140, 3342591);
    await drawLine(343, 140, 341, 136, 8323327);
    await drawLine(341, 136, 339, 112, 13369599);
    await drawLine(339, 112, 334, 111, 16711910);
    await drawLine(337, 129, 337, 124, 16711833);
    await drawLine(337, 124, 338, 127, 16711756);
}

main();
