const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(321, 105, 298, 115, 16711680);
    await drawLine(298, 115, 283, 128, 16728064);
    await drawLine(283, 128, 262, 140, 16744448);
    await drawLine(262, 140, 251, 157, 16760576);
    await drawLine(251, 157, 256, 231, 16776960);
    await drawLine(256, 231, 286, 276, 12582656);
    await drawLine(286, 276, 308, 287, 8453888);
    await drawLine(308, 287, 342, 280, 4259584);
    await drawLine(342, 280, 368, 267, 65280);
    await drawLine(368, 267, 376, 278, 65344);
    await drawLine(376, 278, 377, 276, 65408);
    await drawLine(377, 276, 381, 277, 65471);
    await drawLine(381, 277, 387, 290, 65535);
    await drawLine(387, 290, 391, 291, 49151);
    await drawLine(391, 291, 393, 287, 32767);
    await drawLine(393, 287, 381, 260, 16639);
    await drawLine(381, 260, 383, 256, 255);
    await drawLine(383, 256, 417, 227, 4194559);
    await drawLine(417, 227, 425, 209, 8323327);
    await drawLine(425, 209, 421, 175, 12517631);
    await drawLine(421, 175, 369, 116, 16711935);
    await drawLine(369, 116, 326, 103, 16711871);
    await drawLine(326, 103, 321, 104, 16711808);
    await drawLine(372, 265, 374, 266, 16711744);
}

main();
