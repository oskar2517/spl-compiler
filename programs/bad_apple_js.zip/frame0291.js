const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(587, 337, 585, 341, 16711680);
    await drawLine(585, 341, 584, 341, 16728064);
    await drawLine(584, 341, 576, 342, 16744448);
    await drawLine(576, 342, 573, 344, 16760576);
    await drawLine(573, 344, 568, 363, 16776960);
    await drawLine(568, 363, 526, 379, 12582656);
    await drawLine(526, 379, 443, 457, 8453888);
    await drawLine(443, 457, 427, 476, 4259584);
    await drawLine(427, 476, 427, 479, 65280);
    await drawLine(427, 479, 552, 480, 65344);
    await drawLine(552, 480, 555, 477, 65408);
    await drawLine(555, 477, 568, 440, 65471);
    await drawLine(568, 440, 579, 431, 65535);
    await drawLine(579, 431, 594, 430, 49151);
    await drawLine(594, 430, 599, 428, 32767);
    await drawLine(599, 428, 604, 409, 16639);
    await drawLine(604, 409, 607, 405, 255);
    await drawLine(607, 405, 612, 403, 4194559);
    await drawLine(612, 403, 615, 400, 8323327);
    await drawLine(615, 400, 619, 392, 12517631);
    await drawLine(619, 392, 595, 349, 16711935);
    await drawLine(595, 349, 587, 343, 16711871);
    await drawLine(587, 343, 592, 340, 16711808);
    await drawLine(592, 340, 590, 338, 16711744);
}

main();
