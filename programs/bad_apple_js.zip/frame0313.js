const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(328, 257, 307, 270, 16711680);
    await drawLine(307, 270, 272, 319, 16732416);
    await drawLine(272, 319, 271, 343, 16752896);
    await drawLine(271, 343, 318, 412, 16773632);
    await drawLine(318, 412, 350, 425, 12386048);
    await drawLine(350, 425, 374, 420, 7077632);
    await drawLine(374, 420, 390, 408, 1834752);
    await drawLine(390, 408, 411, 387, 65334);
    await drawLine(411, 387, 413, 390, 65414);
    await drawLine(413, 390, 417, 392, 65495);
    await drawLine(417, 392, 426, 402, 55295);
    await drawLine(426, 402, 428, 398, 34559);
    await drawLine(428, 398, 415, 378, 14079);
    await drawLine(415, 378, 437, 334, 1769727);
    await drawLine(437, 334, 436, 314, 7012607);
    await drawLine(436, 314, 404, 276, 12321023);
    await drawLine(404, 276, 343, 256, 16711922);
    await drawLine(343, 256, 338, 256, 16711841);
    await drawLine(338, 256, 328, 256, 16711761);
}

main();
