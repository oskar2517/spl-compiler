const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(328, 202, 291, 216, 16711680);
    await drawLine(291, 216, 278, 231, 16733440);
    await drawLine(278, 231, 273, 290, 16755200);
    await drawLine(273, 290, 278, 299, 16776960);
    await drawLine(278, 299, 276, 301, 11206400);
    await drawLine(276, 301, 261, 306, 5635840);
    await drawLine(261, 306, 259, 310, 65280);
    await drawLine(259, 310, 263, 312, 65365);
    await drawLine(263, 312, 282, 307, 65450);
    await drawLine(282, 307, 285, 311, 65535);
    await drawLine(285, 311, 298, 338, 43775);
    await drawLine(298, 338, 344, 356, 22015);
    await drawLine(344, 356, 372, 348, 255);
    await drawLine(372, 348, 416, 309, 5570815);
    await drawLine(416, 309, 428, 277, 11141375);
    await drawLine(428, 277, 425, 257, 16711935);
    await drawLine(425, 257, 403, 218, 16711850);
    await drawLine(403, 218, 367, 202, 16711765);
}

main();
