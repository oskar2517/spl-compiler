const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(339, 141, 268, 175, 16711680);
    await drawLine(268, 175, 251, 199, 16726784);
    await drawLine(251, 199, 249, 219, 16741888);
    await drawLine(249, 219, 259, 242, 16756992);
    await drawLine(259, 242, 275, 267, 16771840);
    await drawLine(275, 267, 276, 271, 14221056);
    await drawLine(276, 271, 263, 279, 10354432);
    await drawLine(263, 279, 258, 280, 6487808);
    await drawLine(258, 280, 254, 282, 2621184);
    await drawLine(254, 282, 256, 283, 65300);
    await drawLine(256, 283, 256, 288, 65358);
    await drawLine(256, 288, 260, 291, 65417);
    await drawLine(260, 291, 265, 290, 65476);
    await drawLine(265, 290, 281, 279, 65535);
    await drawLine(281, 279, 285, 279, 50431);
    await drawLine(285, 279, 311, 309, 35327);
    await drawLine(311, 309, 339, 318, 20223);
    await drawLine(339, 318, 377, 304, 5375);
    await drawLine(377, 304, 406, 278, 2556159);
    await drawLine(406, 278, 427, 233, 6422783);
    await drawLine(427, 233, 425, 199, 10289407);
    await drawLine(425, 199, 414, 182, 14156031);
    await drawLine(414, 182, 401, 174, 16711915);
    await drawLine(401, 174, 381, 146, 16711857);
    await drawLine(381, 146, 362, 139, 16711798);
    await drawLine(362, 139, 357, 139, 16711739);
}

main();
