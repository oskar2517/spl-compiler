const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(0, 240, 0, 480, 16711680);
    await drawLine(0, 480, 560, 480, 16728832);
    await drawLine(560, 480, 559, 476, 16745728);
    await drawLine(559, 476, 548, 448, 16762880);
    await drawLine(548, 448, 543, 447, 16056064);
    await drawLine(543, 447, 540, 444, 11665152);
    await drawLine(540, 444, 540, 439, 7339776);
    await drawLine(540, 439, 543, 436, 2948864);
    await drawLine(543, 436, 514, 367, 65302);
    await drawLine(514, 367, 510, 223, 65369);
    await drawLine(510, 223, 512, 220, 65435);
    await drawLine(512, 220, 529, 210, 65502);
    await drawLine(529, 210, 538, 208, 57087);
    await drawLine(538, 208, 547, 203, 39935);
    await drawLine(547, 203, 552, 191, 23039);
    await drawLine(552, 191, 538, 177, 5887);
    await drawLine(538, 177, 512, -(1), 2883839);
    await drawLine(512, -(1), 432, -(1), 7274751);
    await drawLine(432, -(1), 427, 0, 11600127);
    await drawLine(427, 0, 177, -(1), 15991039);
    await drawLine(177, -(1), 172, 0, 16711880);
    await drawLine(172, 0, 2, 0, 16711813);
    await drawLine(2, 0, 0, 2, 16711747);
}

main();
