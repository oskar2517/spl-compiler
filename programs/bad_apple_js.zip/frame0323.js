const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(307, 167, 284, 176, 16711680);
    await drawLine(284, 176, 272, 192, 16729600);
    await drawLine(272, 192, 266, 246, 16747264);
    await drawLine(266, 246, 262, 248, 16765184);
    await drawLine(262, 248, 257, 248, 15269632);
    await drawLine(257, 248, 242, 248, 10682112);
    await drawLine(242, 248, 240, 252, 6160128);
    await drawLine(240, 252, 241, 257, 1572608);
    await drawLine(241, 257, 265, 259, 65326);
    await drawLine(265, 259, 269, 261, 65396);
    await drawLine(269, 261, 274, 301, 65465);
    await drawLine(274, 301, 290, 320, 65535);
    await drawLine(290, 320, 312, 330, 47615);
    await drawLine(312, 330, 377, 324, 29951);
    await drawLine(377, 324, 413, 300, 12031);
    await drawLine(413, 300, 427, 273, 1507583);
    await drawLine(427, 273, 425, 248, 6095103);
    await drawLine(425, 248, 422, 239, 10617087);
    await drawLine(422, 239, 422, 210, 15204607);
    await drawLine(422, 210, 410, 188, 16711889);
    await drawLine(410, 188, 350, 164, 16711819);
    await drawLine(350, 164, 335, 164, 16711750);
}

main();
