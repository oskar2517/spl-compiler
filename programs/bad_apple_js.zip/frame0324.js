const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(332, 154, 276, 174, 16711680);
    await drawLine(276, 174, 260, 193, 16732416);
    await drawLine(260, 193, 257, 217, 16752896);
    await drawLine(257, 217, 268, 256, 16773632);
    await drawLine(268, 256, 268, 260, 12386048);
    await drawLine(268, 260, 244, 265, 7077632);
    await drawLine(244, 265, 245, 274, 1834752);
    await drawLine(245, 274, 249, 276, 65334);
    await drawLine(249, 276, 273, 270, 65414);
    await drawLine(273, 270, 292, 310, 65495);
    await drawLine(292, 310, 313, 323, 55295);
    await drawLine(313, 323, 348, 323, 34559);
    await drawLine(348, 323, 412, 286, 14079);
    await drawLine(412, 286, 428, 256, 1769727);
    await drawLine(428, 256, 426, 221, 7012607);
    await drawLine(426, 221, 415, 205, 12321023);
    await drawLine(415, 205, 403, 173, 16711922);
    await drawLine(403, 173, 383, 158, 16711841);
    await drawLine(383, 158, 349, 153, 16711761);
}

main();
