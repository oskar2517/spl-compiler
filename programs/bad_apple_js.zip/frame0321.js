const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(343, 193, 297, 222, 16711680);
    await drawLine(297, 222, 289, 216, 16732416);
    await drawLine(289, 216, 279, 206, 16752896);
    await drawLine(279, 206, 276, 209, 16773632);
    await drawLine(276, 209, 277, 214, 12386048);
    await drawLine(277, 214, 290, 230, 7077632);
    await drawLine(290, 230, 288, 234, 1834752);
    await drawLine(288, 234, 263, 264, 65334);
    await drawLine(263, 264, 259, 289, 65414);
    await drawLine(259, 289, 272, 321, 65495);
    await drawLine(272, 321, 326, 364, 55295);
    await drawLine(326, 364, 365, 369, 34559);
    await drawLine(365, 369, 383, 360, 14079);
    await drawLine(383, 360, 403, 337, 1769727);
    await drawLine(403, 337, 423, 323, 7012607);
    await drawLine(423, 323, 433, 290, 12321023);
    await drawLine(433, 290, 411, 230, 16711922);
    await drawLine(411, 230, 371, 194, 16711841);
    await drawLine(371, 194, 356, 190, 16711761);
}

main();
