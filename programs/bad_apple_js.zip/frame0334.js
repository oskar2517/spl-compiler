const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(325, 111, 273, 149, 16711680);
    await drawLine(273, 149, 248, 213, 16732416);
    await drawLine(248, 213, 248, 223, 16752896);
    await drawLine(248, 223, 258, 246, 16773632);
    await drawLine(258, 246, 298, 289, 12386048);
    await drawLine(298, 289, 342, 295, 7077632);
    await drawLine(342, 295, 417, 258, 1834752);
    await drawLine(417, 258, 437, 230, 65334);
    await drawLine(437, 230, 434, 201, 65414);
    await drawLine(434, 201, 408, 159, 65495);
    await drawLine(408, 159, 410, 155, 55295);
    await drawLine(410, 155, 431, 144, 34559);
    await drawLine(431, 144, 432, 139, 14079);
    await drawLine(432, 139, 432, 134, 1769727);
    await drawLine(432, 134, 428, 132, 7012607);
    await drawLine(428, 132, 402, 146, 12321023);
    await drawLine(402, 146, 397, 145, 16711922);
    await drawLine(397, 145, 359, 114, 16711841);
    await drawLine(359, 114, 335, 110, 16711761);
}

main();
