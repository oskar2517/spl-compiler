const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(368, 160, 326, 175, 16711680);
    await drawLine(326, 175, 279, 232, 16741888);
    await drawLine(279, 232, 273, 271, 16771840);
    await drawLine(273, 271, 292, 317, 10354432);
    await drawLine(292, 317, 367, 357, 2621184);
    await drawLine(367, 357, 391, 356, 65358);
    await drawLine(391, 356, 444, 318, 65476);
    await drawLine(444, 318, 464, 238, 50431);
    await drawLine(464, 238, 457, 204, 20223);
    await drawLine(457, 204, 444, 189, 2556159);
    await drawLine(444, 189, 421, 178, 10289407);
    await drawLine(421, 178, 393, 160, 16711915);
    await drawLine(393, 160, 378, 159, 16711798);
}

main();
