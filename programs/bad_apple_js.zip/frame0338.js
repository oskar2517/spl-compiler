const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(309, 129, 307, 133, 16711680);
    await drawLine(307, 133, 311, 148, 16734720);
    await drawLine(311, 148, 310, 152, 16757760);
    await drawLine(310, 152, 265, 189, 15793920);
    await drawLine(265, 189, 257, 217, 9895680);
    await drawLine(257, 217, 292, 288, 3997440);
    await drawLine(292, 288, 332, 317, 65310);
    await drawLine(332, 317, 356, 322, 65400);
    await drawLine(356, 322, 434, 280, 65490);
    await drawLine(434, 280, 446, 258, 54015);
    await drawLine(446, 258, 429, 166, 30975);
    await drawLine(429, 166, 407, 140, 7935);
    await drawLine(407, 140, 379, 130, 3932415);
    await drawLine(379, 130, 374, 130, 9830655);
    await drawLine(374, 130, 322, 146, 15728895);
    await drawLine(322, 146, 317, 128, 16711860);
    await drawLine(317, 128, 313, 126, 16711770);
}

main();
