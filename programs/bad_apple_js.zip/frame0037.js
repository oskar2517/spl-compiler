const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(0, 240, 0, 480, 16711680);
    await drawLine(0, 480, 640, 480, 16729600);
    await drawLine(640, 480, 639, 365, 16747264);
    await drawLine(639, 365, 593, 334, 16765184);
    await drawLine(593, 334, 603, 1, 15269632);
    await drawLine(603, 1, 599, -(1), 10682112);
    await drawLine(599, -(1), 479, -(1), 6160128);
    await drawLine(479, -(1), 474, 0, 1572608);
    await drawLine(474, 0, 179, -(1), 65326);
    await drawLine(179, -(1), 174, 0, 65396);
    await drawLine(174, 0, 4, 0, 65465);
    await drawLine(4, 0, 0, 0, 65535);
    await drawLine(0, 0, 0, 235, 47615);
    await drawLine(582, 296, 589, 330, 29951);
    await drawLine(589, 330, 585, 330, 12031);
    await drawLine(585, 330, 572, 323, 1507583);
    await drawLine(572, 323, 571, 318, 6095103);
    await drawLine(571, 318, 579, 290, 10617087);
    await drawLine(579, 290, 581, 295, 15204607);
    await drawLine(635, 4, 640, 12, 16711889);
    await drawLine(640, 12, 640, 2, 16711819);
    await drawLine(640, 2, 637, 0, 16711750);
}

main();
