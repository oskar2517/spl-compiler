const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(285, 14, 259, 25, 16711680);
    await drawLine(259, 25, 242, 70, 16737792);
    await drawLine(242, 70, 247, 104, 16763904);
    await drawLine(247, 104, 295, 138, 13434624);
    await drawLine(295, 138, 324, 141, 6749952);
    await drawLine(324, 141, 338, 137, 65280);
    await drawLine(338, 137, 355, 118, 65382);
    await drawLine(355, 118, 362, 100, 65484);
    await drawLine(362, 100, 366, 102, 52479);
    await drawLine(366, 102, 369, 100, 26367);
    await drawLine(369, 100, 363, 91, 255);
    await drawLine(363, 91, 366, 57, 6684927);
    await drawLine(366, 57, 355, 35, 13369599);
    await drawLine(355, 35, 326, 16, 16711884);
    await drawLine(326, 16, 296, 13, 16711782);
}

main();
