const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(355, 108, 347, 136, 16711680);
    await drawLine(347, 136, 342, 138, 16728832);
    await drawLine(342, 138, 337, 138, 16745728);
    await drawLine(337, 138, 322, 138, 16762880);
    await drawLine(322, 138, 292, 140, 16056064);
    await drawLine(292, 140, 276, 151, 11665152);
    await drawLine(276, 151, 261, 187, 7339776);
    await drawLine(261, 187, 278, 274, 2948864);
    await drawLine(278, 274, 301, 300, 65302);
    await drawLine(301, 300, 320, 305, 65369);
    await drawLine(320, 305, 335, 303, 65435);
    await drawLine(335, 303, 374, 308, 65502);
    await drawLine(374, 308, 405, 293, 57087);
    await drawLine(405, 293, 434, 247, 39935);
    await drawLine(434, 247, 440, 182, 23039);
    await drawLine(440, 182, 431, 160, 5887);
    await drawLine(431, 160, 406, 143, 2883839);
    await drawLine(406, 143, 362, 138, 7274751);
    await drawLine(362, 138, 360, 134, 11600127);
    await drawLine(360, 134, 366, 110, 15991039);
    await drawLine(366, 110, 364, 106, 16711880);
    await drawLine(364, 106, 360, 104, 16711813);
    await drawLine(360, 104, 356, 106, 16711747);
}

main();
