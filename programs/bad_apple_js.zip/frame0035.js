const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(0, 240, 0, 480, 16711680);
    await drawLine(0, 480, 640, 480, 16747264);
    await drawLine(640, 480, 639, 251, 15269632);
    await drawLine(639, 251, 629, 248, 6160128);
    await drawLine(629, 248, 639, -(1), 65326);
    await drawLine(639, -(1), 494, -(1), 65465);
    await drawLine(494, -(1), 489, 0, 47615);
    await drawLine(489, 0, 174, -(1), 12031);
    await drawLine(174, -(1), 169, 0, 6095103);
    await drawLine(169, 0, 4, 0, 15204607);
    await drawLine(4, 0, 0, 0, 16711819);
}

main();
