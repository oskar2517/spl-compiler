const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(182, 4, 183, 8, 16711680);
    await drawLine(183, 8, 301, 20, 16728064);
    await drawLine(301, 20, 310, 24, 16744448);
    await drawLine(310, 24, 635, 34, 16760576);
    await drawLine(635, 34, 639, 32, 16776960);
    await drawLine(639, 32, 640, 2, 12582656);
    await drawLine(640, 2, 637, -(1), 8453888);
    await drawLine(637, -(1), 587, -(1), 4259584);
    await drawLine(587, -(1), 582, 0, 65280);
    await drawLine(582, 0, 357, -(1), 65344);
    await drawLine(357, -(1), 352, 0, 65408);
    await drawLine(352, 0, 182, 0, 65471);
    await drawLine(355, 176, 301, 185, 65535);
    await drawLine(301, 185, 275, 208, 49151);
    await drawLine(275, 208, 261, 270, 32767);
    await drawLine(261, 270, 278, 322, 16639);
    await drawLine(278, 322, 319, 357, 255);
    await drawLine(319, 357, 348, 363, 4194559);
    await drawLine(348, 363, 387, 351, 8323327);
    await drawLine(387, 351, 441, 294, 12517631);
    await drawLine(441, 294, 449, 256, 16711935);
    await drawLine(449, 256, 437, 218, 16711871);
    await drawLine(437, 218, 427, 207, 16711808);
    await drawLine(427, 207, 382, 176, 16711744);
}

main();
