const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(326, 263, 299, 275, 16711680);
    await drawLine(299, 275, 283, 301, 16729600);
    await drawLine(283, 301, 279, 320, 16747264);
    await drawLine(279, 320, 270, 338, 16765184);
    await drawLine(270, 338, 270, 357, 15269632);
    await drawLine(270, 357, 291, 391, 10682112);
    await drawLine(291, 391, 352, 424, 6160128);
    await drawLine(352, 424, 381, 424, 1572608);
    await drawLine(381, 424, 398, 413, 65326);
    await drawLine(398, 413, 419, 379, 65396);
    await drawLine(419, 379, 426, 374, 65465);
    await drawLine(426, 374, 430, 373, 65535);
    await drawLine(430, 373, 438, 378, 47615);
    await drawLine(438, 378, 441, 375, 29951);
    await drawLine(441, 375, 438, 371, 12031);
    await drawLine(438, 371, 426, 362, 1507583);
    await drawLine(426, 362, 433, 308, 6095103);
    await drawLine(433, 308, 417, 283, 10617087);
    await drawLine(417, 283, 362, 262, 15204607);
    await drawLine(362, 262, 337, 261, 16711889);
    await drawLine(337, 261, 327, 262, 16711819);
    await drawLine(427, 378, 427, 377, 16711750);
}

main();
