const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(339, 109, 274, 143, 16711680);
    await drawLine(274, 143, 247, 185, 16730368);
    await drawLine(247, 185, 245, 210, 16749056);
    await drawLine(245, 210, 250, 224, 16767744);
    await drawLine(250, 224, 272, 268, 14417664);
    await drawLine(272, 268, 317, 288, 9633536);
    await drawLine(317, 288, 394, 275, 4849408);
    await drawLine(394, 275, 421, 253, 65280);
    await drawLine(421, 253, 429, 235, 65353);
    await drawLine(429, 235, 417, 177, 65426);
    await drawLine(417, 177, 418, 173, 65499);
    await drawLine(418, 173, 422, 173, 56319);
    await drawLine(422, 173, 441, 171, 37631);
    await drawLine(441, 171, 444, 167, 18943);
    await drawLine(444, 167, 445, 157, 255);
    await drawLine(445, 157, 440, 155, 4784383);
    await drawLine(440, 155, 411, 163, 9568511);
    await drawLine(411, 163, 380, 119, 14352639);
    await drawLine(380, 119, 348, 108, 16711899);
    await drawLine(348, 108, 343, 108, 16711826);
    await drawLine(431, 167, 428, 166, 16711753);
}

main();
