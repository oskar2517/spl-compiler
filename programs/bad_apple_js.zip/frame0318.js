const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(386, 233, 375, 248, 16711680);
    await drawLine(375, 248, 331, 237, 16734720);
    await drawLine(331, 237, 308, 244, 16757760);
    await drawLine(308, 244, 275, 293, 15793920);
    await drawLine(275, 293, 271, 347, 9895680);
    await drawLine(271, 347, 283, 374, 3997440);
    await drawLine(283, 374, 304, 387, 65310);
    await drawLine(304, 387, 319, 391, 65400);
    await drawLine(319, 391, 334, 403, 65490);
    await drawLine(334, 403, 363, 407, 54015);
    await drawLine(363, 407, 421, 361, 30975);
    await drawLine(421, 361, 437, 325, 7935);
    await drawLine(437, 325, 435, 295, 3932415);
    await drawLine(435, 295, 393, 254, 9830655);
    await drawLine(393, 254, 384, 249, 15728895);
    await drawLine(384, 249, 390, 236, 16711860);
    await drawLine(390, 236, 390, 232, 16711770);
}

main();
