const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(232, 7, 252, 56, 16711680);
    await drawLine(252, 56, 270, 73, 16744448);
    await drawLine(270, 73, 295, 76, 16776960);
    await drawLine(295, 76, 325, 59, 8453888);
    await drawLine(325, 59, 330, 67, 65280);
    await drawLine(330, 67, 333, 67, 65408);
    await drawLine(333, 67, 333, 62, 65535);
    await drawLine(333, 62, 329, 53, 32767);
    await drawLine(329, 53, 350, 19, 255);
    await drawLine(350, 19, 348, 0, 8323327);
    await drawLine(348, 0, 233, 0, 16711935);
    await drawLine(233, 0, 232, 3, 16711808);
}

main();
