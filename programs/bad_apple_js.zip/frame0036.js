const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(0, 240, 0, 480, 16711680);
    await drawLine(0, 480, 640, 480, 16730368);
    await drawLine(640, 480, 640, 360, 16749056);
    await drawLine(640, 360, 638, 356, 16767744);
    await drawLine(638, 356, 607, 339, 14417664);
    await drawLine(607, 339, 604, 335, 9633536);
    await drawLine(604, 335, 604, 261, 4849408);
    await drawLine(604, 261, 628, 3, 65280);
    await drawLine(628, 3, 626, -(1), 65353);
    await drawLine(626, -(1), 491, -(1), 65426);
    await drawLine(491, -(1), 486, 0, 65499);
    await drawLine(486, 0, 176, -(1), 56319);
    await drawLine(176, -(1), 171, 0, 37631);
    await drawLine(171, 0, 1, 0, 18943);
    await drawLine(1, 0, 0, 3, 255);
    await drawLine(0, 3, 0, 238, 4784383);
    await drawLine(592, 327, 593, 332, 9568511);
    await drawLine(593, 332, 588, 330, 14352639);
    await drawLine(588, 330, 585, 326, 16711899);
    await drawLine(585, 326, 589, 317, 16711826);
    await drawLine(589, 317, 591, 320, 16711753);
}

main();
