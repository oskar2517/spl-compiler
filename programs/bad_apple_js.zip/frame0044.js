const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(0, 240, 0, 480, 16711680);
    await drawLine(0, 480, 574, 479, 16726272);
    await drawLine(574, 479, 575, 476, 16740608);
    await drawLine(575, 476, 524, 437, 16755200);
    await drawLine(524, 437, 515, 433, 16769792);
    await drawLine(515, 433, 512, 429, 14941952);
    await drawLine(512, 429, 499, 336, 11206400);
    await drawLine(499, 336, 436, 267, 7470848);
    await drawLine(436, 267, 384, 238, 3800832);
    await drawLine(384, 238, 385, 234, 65280);
    await drawLine(385, 234, 412, 192, 65337);
    await drawLine(412, 192, 411, 188, 65393);
    await drawLine(411, 188, 396, 185, 65450);
    await drawLine(396, 185, 392, 183, 65507);
    await drawLine(392, 183, 391, 178, 58367);
    await drawLine(391, 178, 386, 75, 43775);
    await drawLine(386, 75, 423, 4, 29183);
    await drawLine(423, 4, 424, 0, 14847);
    await drawLine(424, 0, 179, -(1), 255);
    await drawLine(179, -(1), 174, 0, 3735807);
    await drawLine(174, 0, 4, 0, 7405823);
    await drawLine(4, 0, 0, 0, 11141375);
    await drawLine(0, 0, 0, 235, 14876927);
    await drawLine(382, 180, 383, 184, 16711907);
    await drawLine(383, 184, 378, 184, 16711850);
    await drawLine(378, 184, 377, 181, 16711793);
    await drawLine(377, 181, 378, 176, 16711737);
}

main();
