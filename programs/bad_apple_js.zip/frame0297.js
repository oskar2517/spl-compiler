const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(263, 1, 240, 50, 16711680);
    await drawLine(240, 50, 240, 70, 16736256);
    await drawLine(240, 70, 280, 112, 16760576);
    await drawLine(280, 112, 308, 123, 14679808);
    await drawLine(308, 123, 313, 122, 8453888);
    await drawLine(313, 122, 341, 102, 2162432);
    await drawLine(341, 102, 351, 86, 65344);
    await drawLine(351, 86, 361, 96, 65439);
    await drawLine(361, 96, 363, 93, 65535);
    await drawLine(363, 93, 354, 81, 40959);
    await drawLine(354, 81, 353, 77, 16639);
    await drawLine(353, 77, 361, 48, 2097407);
    await drawLine(361, 48, 355, 24, 8323327);
    await drawLine(355, 24, 329, 2, 14614783);
    await drawLine(329, 2, 324, 0, 16711871);
    await drawLine(324, 0, 294, 0, 16711776);
}

main();
