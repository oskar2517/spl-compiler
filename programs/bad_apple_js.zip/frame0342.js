const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(349, 157, 298, 175, 16711680);
    await drawLine(298, 175, 271, 238, 16744448);
    await drawLine(271, 238, 278, 281, 16776960);
    await drawLine(278, 281, 312, 331, 8453888);
    await drawLine(312, 331, 350, 341, 65280);
    await drawLine(350, 341, 425, 317, 65408);
    await drawLine(425, 317, 463, 272, 65535);
    await drawLine(463, 272, 467, 253, 32767);
    await drawLine(467, 253, 463, 233, 255);
    await drawLine(463, 233, 448, 187, 8323327);
    await drawLine(448, 187, 406, 161, 16711935);
    await drawLine(406, 161, 361, 156, 16711808);
}

main();
