const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(363, 168, 317, 186, 16711680);
    await drawLine(317, 186, 310, 193, 16730368);
    await drawLine(310, 193, 288, 206, 16749056);
    await drawLine(288, 206, 276, 233, 16767744);
    await drawLine(276, 233, 293, 320, 14417664);
    await drawLine(293, 320, 311, 343, 9633536);
    await drawLine(311, 343, 348, 356, 4849408);
    await drawLine(348, 356, 400, 340, 65280);
    await drawLine(400, 340, 404, 342, 65353);
    await drawLine(404, 342, 416, 363, 65426);
    await drawLine(416, 363, 419, 365, 65499);
    await drawLine(419, 365, 424, 363, 56319);
    await drawLine(424, 363, 423, 358, 37631);
    await drawLine(423, 358, 411, 342, 18943);
    await drawLine(411, 342, 410, 338, 255);
    await drawLine(410, 338, 413, 334, 4784383);
    await drawLine(413, 334, 452, 303, 9568511);
    await drawLine(452, 303, 466, 261, 14352639);
    await drawLine(466, 261, 445, 212, 16711899);
    await drawLine(445, 212, 387, 166, 16711826);
    await drawLine(387, 166, 377, 164, 16711753);
}

main();
