const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(336, 171, 311, 175, 16711680);
    await drawLine(311, 175, 294, 192, 16733440);
    await drawLine(294, 192, 275, 232, 16755200);
    await drawLine(275, 232, 255, 228, 16776960);
    await drawLine(255, 228, 252, 231, 11206400);
    await drawLine(252, 231, 254, 235, 5635840);
    await drawLine(254, 235, 273, 240, 65280);
    await drawLine(273, 240, 275, 243, 65365);
    await drawLine(275, 243, 270, 267, 65450);
    await drawLine(270, 267, 275, 291, 65535);
    await drawLine(275, 291, 303, 319, 43775);
    await drawLine(303, 319, 367, 322, 22015);
    await drawLine(367, 322, 405, 299, 255);
    await drawLine(405, 299, 418, 273, 5570815);
    await drawLine(418, 273, 418, 248, 11141375);
    await drawLine(418, 248, 419, 238, 16711935);
    await drawLine(419, 238, 410, 216, 16711850);
    await drawLine(410, 216, 354, 175, 16711765);
}

main();
