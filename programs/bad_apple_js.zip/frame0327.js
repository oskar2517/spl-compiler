const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(344, 118, 334, 119, 16711680);
    await drawLine(334, 119, 314, 117, 16724736);
    await drawLine(314, 117, 290, 123, 16737792);
    await drawLine(290, 123, 251, 196, 16750848);
    await drawLine(251, 196, 251, 241, 16763904);
    await drawLine(251, 241, 263, 262, 16776960);
    await drawLine(263, 262, 285, 274, 13434624);
    await drawLine(285, 274, 325, 277, 10092288);
    await drawLine(325, 277, 327, 280, 6749952);
    await drawLine(327, 280, 326, 285, 3407616);
    await drawLine(326, 285, 326, 290, 65280);
    await drawLine(326, 290, 328, 291, 65331);
    await drawLine(328, 291, 330, 290, 65382);
    await drawLine(330, 290, 330, 300, 65433);
    await drawLine(330, 300, 327, 303, 65484);
    await drawLine(327, 303, 330, 310, 65535);
    await drawLine(330, 310, 334, 309, 52479);
    await drawLine(334, 309, 337, 305, 39423);
    await drawLine(337, 305, 340, 280, 26367);
    await drawLine(340, 280, 343, 278, 13311);
    await drawLine(343, 278, 382, 277, 255);
    await drawLine(382, 277, 406, 260, 3342591);
    await drawLine(406, 260, 421, 213, 6684927);
    await drawLine(421, 213, 405, 151, 10027263);
    await drawLine(405, 151, 374, 119, 13369599);
    await drawLine(374, 119, 354, 116, 16711935);
    await drawLine(354, 116, 345, 117, 16711884);
    await drawLine(324, 300, 326, 296, 16711833);
    await drawLine(321, 305, 321, 307, 16711782);
    await drawLine(321, 307, 324, 303, 16711731);
}

main();
