const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(0, 240, 0, 480, 16711680);
    await drawLine(0, 480, 614, 479, 16726784);
    await drawLine(614, 479, 614, 475, 16741888);
    await drawLine(614, 475, 565, 427, 16756992);
    await drawLine(565, 427, 547, 419, 16771840);
    await drawLine(547, 419, 544, 310, 14221056);
    await drawLine(544, 310, 464, 223, 10354432);
    await drawLine(464, 223, 438, 209, 6487808);
    await drawLine(438, 209, 442, 185, 2621184);
    await drawLine(442, 185, 458, 159, 65300);
    await drawLine(458, 159, 458, 156, 65358);
    await drawLine(458, 156, 373, 150, 65417);
    await drawLine(373, 150, 372, 146, 65476);
    await drawLine(372, 146, 395, 91, 65535);
    await drawLine(395, 91, 417, 21, 50431);
    await drawLine(417, 21, 424, 10, 35327);
    await drawLine(424, 10, 400, 85, 20223);
    await drawLine(400, 85, 401, 90, 5375);
    await drawLine(401, 90, 401, 94, 2556159);
    await drawLine(401, 94, 403, 93, 6422783);
    await drawLine(403, 93, 455, 1, 10289407);
    await drawLine(455, 1, 177, -(1), 14156031);
    await drawLine(177, -(1), 172, 0, 16711915);
    await drawLine(172, 0, 2, 0, 16711857);
    await drawLine(2, 0, 0, 2, 16711798);
    await drawLine(0, 2, 0, 237, 16711739);
}

main();
