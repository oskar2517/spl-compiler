const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(330, 207, 329, 226, 16711680);
    await drawLine(329, 226, 327, 229, 16732416);
    await drawLine(327, 229, 285, 244, 16752896);
    await drawLine(285, 244, 268, 269, 16773632);
    await drawLine(268, 269, 280, 346, 12386048);
    await drawLine(280, 346, 304, 378, 7077632);
    await drawLine(304, 378, 327, 386, 1834752);
    await drawLine(327, 386, 361, 379, 65334);
    await drawLine(361, 379, 391, 379, 65414);
    await drawLine(391, 379, 404, 372, 65495);
    await drawLine(404, 372, 428, 318, 55295);
    await drawLine(428, 318, 425, 264, 34559);
    await drawLine(425, 264, 411, 237, 14079);
    await drawLine(411, 237, 384, 226, 1769727);
    await drawLine(384, 226, 354, 224, 7012607);
    await drawLine(354, 224, 339, 225, 12321023);
    await drawLine(339, 225, 336, 221, 16711922);
    await drawLine(336, 221, 335, 207, 16711841);
    await drawLine(335, 207, 332, 204, 16711761);
}

main();
