const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(0, 240, 0, 480, 16711680);
    await drawLine(0, 480, 595, 480, 16727296);
    await drawLine(595, 480, 595, 477, 16742912);
    await drawLine(595, 477, 543, 431, 16758784);
    await drawLine(543, 431, 529, 426, 16774400);
    await drawLine(529, 426, 524, 327, 13434624);
    await drawLine(524, 327, 469, 257, 9436928);
    await drawLine(469, 257, 413, 225, 5439232);
    await drawLine(413, 225, 412, 221, 1376000);
    await drawLine(412, 221, 415, 207, 65321);
    await drawLine(415, 207, 436, 173, 65382);
    await drawLine(436, 173, 432, 171, 65443);
    await drawLine(432, 171, 373, 165, 65504);
    await drawLine(373, 165, 370, 156, 57599);
    await drawLine(370, 156, 382, 103, 41983);
    await drawLine(382, 103, 439, 3, 26367);
    await drawLine(439, 3, 439, 0, 10751);
    await drawLine(439, 0, 174, -(1), 1310975);
    await drawLine(174, -(1), 169, 0, 5374207);
    await drawLine(169, 0, 4, 0, 9371903);
    await drawLine(4, 0, 0, 0, 13369599);
    await drawLine(0, 0, 0, 235, 16711925);
    await drawLine(402, 22, 400, 26, 16711864);
    await drawLine(400, 26, 399, 27, 16711802);
    await drawLine(399, 27, 403, 18, 16711741);
}

main();
