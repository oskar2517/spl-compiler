const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(321, 112, 270, 132, 16711680);
    await drawLine(270, 132, 252, 155, 16732416);
    await drawLine(252, 155, 245, 219, 16752896);
    await drawLine(245, 219, 273, 259, 16773632);
    await drawLine(273, 259, 341, 288, 12386048);
    await drawLine(341, 288, 376, 286, 7077632);
    await drawLine(376, 286, 398, 266, 1834752);
    await drawLine(398, 266, 415, 215, 65334);
    await drawLine(415, 215, 422, 220, 65414);
    await drawLine(422, 220, 425, 218, 65495);
    await drawLine(425, 218, 435, 217, 55295);
    await drawLine(435, 217, 445, 219, 34559);
    await drawLine(445, 219, 447, 216, 14079);
    await drawLine(447, 216, 440, 209, 1769727);
    await drawLine(440, 209, 416, 203, 7012607);
    await drawLine(416, 203, 419, 174, 12321023);
    await drawLine(419, 174, 406, 136, 16711922);
    await drawLine(406, 136, 378, 116, 16711841);
    await drawLine(378, 116, 338, 111, 16711761);
}

main();
