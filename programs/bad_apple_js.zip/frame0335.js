const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(380, 109, 365, 134, 16711680);
    await drawLine(365, 134, 316, 125, 16733440);
    await drawLine(316, 125, 301, 126, 16755200);
    await drawLine(301, 126, 278, 144, 16776960);
    await drawLine(278, 144, 259, 215, 11206400);
    await drawLine(259, 215, 271, 268, 5635840);
    await drawLine(271, 268, 287, 287, 65280);
    await drawLine(287, 287, 316, 296, 65365);
    await drawLine(316, 296, 343, 307, 65450);
    await drawLine(343, 307, 368, 305, 65535);
    await drawLine(368, 305, 424, 257, 43775);
    await drawLine(424, 257, 444, 201, 22015);
    await drawLine(444, 201, 439, 177, 255);
    await drawLine(439, 177, 423, 158, 5570815);
    await drawLine(423, 158, 377, 139, 11141375);
    await drawLine(377, 139, 391, 108, 16711935);
    await drawLine(391, 108, 388, 106, 16711850);
    await drawLine(388, 106, 384, 105, 16711765);
}

main();
