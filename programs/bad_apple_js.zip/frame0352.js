const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(470, 1, 489, 3, 16711680);
    await drawLine(489, 3, 497, 7, 16729600);
    await drawLine(497, 7, 632, 11, 16747264);
    await drawLine(632, 11, 637, 9, 16765184);
    await drawLine(637, 9, 639, 6, 15269632);
    await drawLine(639, 6, 640, 1, 10682112);
    await drawLine(640, 1, 636, 0, 6160128);
    await drawLine(636, 0, 556, 0, 1572608);
    await drawLine(556, 0, 471, 0, 65326);
    await drawLine(334, 174, 295, 194, 65396);
    await drawLine(295, 194, 264, 256, 65465);
    await drawLine(264, 256, 264, 290, 65535);
    await drawLine(264, 290, 296, 341, 47615);
    await drawLine(296, 341, 336, 358, 29951);
    await drawLine(336, 358, 408, 340, 12031);
    await drawLine(408, 340, 446, 301, 1507583);
    await drawLine(446, 301, 452, 257, 6095103);
    await drawLine(452, 257, 446, 233, 10617087);
    await drawLine(446, 233, 426, 210, 15204607);
    await drawLine(426, 210, 423, 201, 16711889);
    await drawLine(423, 201, 400, 181, 16711819);
    await drawLine(400, 181, 346, 173, 16711750);
}

main();
