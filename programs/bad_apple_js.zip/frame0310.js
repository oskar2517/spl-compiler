const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(343, 226, 300, 251, 16711680);
    await drawLine(300, 251, 272, 303, 16733440);
    await drawLine(272, 303, 272, 338, 16755200);
    await drawLine(272, 338, 283, 354, 16776960);
    await drawLine(283, 354, 303, 370, 11206400);
    await drawLine(303, 370, 331, 378, 5635840);
    await drawLine(331, 378, 331, 382, 65280);
    await drawLine(331, 382, 324, 400, 65365);
    await drawLine(324, 400, 325, 404, 65450);
    await drawLine(325, 404, 329, 403, 65535);
    await drawLine(329, 403, 338, 385, 43775);
    await drawLine(338, 385, 341, 381, 22015);
    await drawLine(341, 381, 395, 378, 255);
    await drawLine(395, 378, 418, 359, 5570815);
    await drawLine(418, 359, 425, 291, 11141375);
    await drawLine(425, 291, 409, 249, 16711935);
    await drawLine(409, 249, 397, 240, 16711850);
    await drawLine(397, 240, 350, 225, 16711765);
}

main();
