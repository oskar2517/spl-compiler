const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(320, 99, 310, 98, 16711680);
    await drawLine(310, 98, 295, 100, 16739584);
    await drawLine(295, 100, 272, 118, 16767744);
    await drawLine(272, 118, 256, 159, 11992832);
    await drawLine(256, 159, 269, 216, 4849408);
    await drawLine(269, 216, 289, 239, 65316);
    await drawLine(289, 239, 298, 243, 65426);
    await drawLine(298, 243, 342, 247, 65535);
    await drawLine(342, 247, 380, 217, 37631);
    await drawLine(380, 217, 394, 179, 9471);
    await drawLine(394, 179, 391, 140, 4784383);
    await drawLine(391, 140, 367, 108, 11927807);
    await drawLine(367, 108, 349, 99, 16711899);
    await drawLine(349, 99, 320, 97, 16711789);
}

main();
