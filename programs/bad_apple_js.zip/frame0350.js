const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(346, 176, 291, 199, 16711680);
    await drawLine(291, 199, 272, 222, 16737792);
    await drawLine(272, 222, 268, 286, 16763904);
    await drawLine(268, 286, 327, 351, 13434624);
    await drawLine(327, 351, 374, 365, 6749952);
    await drawLine(374, 365, 407, 354, 65280);
    await drawLine(407, 354, 446, 303, 65382);
    await drawLine(446, 303, 451, 302, 65484);
    await drawLine(451, 302, 465, 307, 52479);
    await drawLine(465, 307, 465, 302, 26367);
    await drawLine(465, 302, 464, 297, 255);
    await drawLine(464, 297, 450, 293, 6684927);
    await drawLine(450, 293, 456, 234, 13369599);
    await drawLine(456, 234, 427, 194, 16711884);
    await drawLine(427, 194, 361, 175, 16711782);
}

main();
