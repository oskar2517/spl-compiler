const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(0, 240, 0, 480, 16711680);
    await drawLine(0, 480, 560, 480, 16723200);
    await drawLine(560, 480, 497, 440, 16734720);
    await drawLine(497, 440, 476, 343, 16746240);
    await drawLine(476, 343, 404, 274, 16757760);
    await drawLine(404, 274, 400, 250, 16769280);
    await drawLine(400, 250, 401, 247, 15793920);
    await drawLine(401, 247, 406, 247, 12844800);
    await drawLine(406, 247, 411, 246, 9895680);
    await drawLine(411, 246, 409, 242, 6946560);
    await drawLine(409, 242, 401, 224, 3997440);
    await drawLine(401, 224, 398, 179, 1048320);
    await drawLine(398, 179, 417, 207, 65310);
    await drawLine(417, 207, 418, 206, 65355);
    await drawLine(418, 206, 412, 187, 65400);
    await drawLine(412, 187, 413, 183, 65445);
    await drawLine(413, 183, 401, 25, 65490);
    await drawLine(401, 25, 409, 7, 65535);
    await drawLine(409, 7, 409, 3, 54015);
    await drawLine(409, 3, 408, -(1), 42495);
    await drawLine(408, -(1), 383, -(1), 30975);
    await drawLine(383, -(1), 378, 0, 19455);
    await drawLine(378, 0, 178, -(1), 7935);
    await drawLine(178, -(1), 173, 0, 983295);
    await drawLine(173, 0, 3, 0, 3932415);
    await drawLine(3, 0, 0, 1, 6881535);
    await drawLine(0, 1, 0, 236, 9830655);
    await drawLine(390, 248, 394, 251, 12779775);
    await drawLine(394, 251, 400, 270, 15728895);
    await drawLine(400, 270, 398, 269, 16711905);
    await drawLine(398, 269, 395, 264, 16711860);
    await drawLine(395, 264, 386, 260, 16711815);
    await drawLine(386, 260, 383, 250, 16711770);
    await drawLine(383, 250, 385, 248, 16711725);
}

main();
