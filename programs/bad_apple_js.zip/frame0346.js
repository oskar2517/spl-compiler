const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(352, 169, 318, 179, 16711680);
    await drawLine(318, 179, 285, 234, 16734720);
    await drawLine(285, 234, 281, 293, 16757760);
    await drawLine(281, 293, 310, 339, 15793920);
    await drawLine(310, 339, 367, 354, 9895680);
    await drawLine(367, 354, 371, 362, 3997440);
    await drawLine(371, 362, 375, 364, 65310);
    await drawLine(375, 364, 378, 360, 65400);
    await drawLine(378, 360, 378, 355, 65490);
    await drawLine(378, 355, 417, 349, 54015);
    await drawLine(417, 349, 454, 316, 30975);
    await drawLine(454, 316, 467, 279, 7935);
    await drawLine(467, 279, 442, 194, 3932415);
    await drawLine(442, 194, 425, 176, 9830655);
    await drawLine(425, 176, 406, 171, 15728895);
    await drawLine(406, 171, 391, 172, 16711860);
    await drawLine(391, 172, 361, 168, 16711770);
}

main();
