const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(370, 159, 303, 190, 16711680);
    await drawLine(303, 190, 276, 225, 16741888);
    await drawLine(276, 225, 278, 289, 16771840);
    await drawLine(278, 289, 298, 317, 10354432);
    await drawLine(298, 317, 351, 353, 2621184);
    await drawLine(351, 353, 386, 352, 65358);
    await drawLine(386, 352, 442, 311, 65476);
    await drawLine(442, 311, 467, 247, 50431);
    await drawLine(467, 247, 462, 212, 20223);
    await drawLine(462, 212, 449, 198, 2556159);
    await drawLine(449, 198, 441, 192, 10289407);
    await drawLine(441, 192, 418, 166, 16711915);
    await drawLine(418, 166, 380, 157, 16711798);
}

main();
