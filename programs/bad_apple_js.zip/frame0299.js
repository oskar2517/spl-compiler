const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(316, 47, 287, 54, 16711680);
    await drawLine(287, 54, 275, 62, 16744448);
    await drawLine(275, 62, 271, 63, 16776960);
    await drawLine(271, 63, 244, 109, 8453888);
    await drawLine(244, 109, 247, 138, 65280);
    await drawLine(247, 138, 275, 173, 65408);
    await drawLine(275, 173, 318, 181, 65535);
    await drawLine(318, 181, 352, 172, 32767);
    await drawLine(352, 172, 376, 147, 255);
    await drawLine(376, 147, 377, 88, 8323327);
    await drawLine(377, 88, 364, 67, 16711935);
    await drawLine(364, 67, 329, 47, 16711808);
}

main();
