const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(342, 173, 300, 189, 16711680);
    await drawLine(300, 189, 281, 211, 16731392);
    await drawLine(281, 211, 267, 259, 16750848);
    await drawLine(267, 259, 311, 341, 16770304);
    await drawLine(311, 341, 349, 363, 13434624);
    await drawLine(349, 363, 373, 365, 8453888);
    await drawLine(373, 365, 397, 355, 3407616);
    await drawLine(397, 355, 432, 320, 65305);
    await drawLine(432, 320, 457, 335, 65382);
    await drawLine(457, 335, 459, 331, 65459);
    await drawLine(459, 331, 459, 327, 65535);
    await drawLine(459, 327, 455, 323, 45823);
    await drawLine(455, 323, 446, 320, 26367);
    await drawLine(446, 320, 439, 315, 6655);
    await drawLine(439, 315, 438, 311, 3342591);
    await drawLine(438, 311, 461, 261, 8323327);
    await drawLine(461, 261, 457, 232, 13369599);
    await drawLine(457, 232, 431, 196, 16711910);
    await drawLine(431, 196, 371, 173, 16711833);
    await drawLine(371, 173, 351, 172, 16711756);
}

main();
