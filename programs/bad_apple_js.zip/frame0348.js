const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(350, 168, 308, 185, 16711680);
    await drawLine(308, 185, 272, 232, 16736256);
    await drawLine(272, 232, 295, 322, 16760576);
    await drawLine(295, 322, 325, 355, 14679808);
    await drawLine(325, 355, 354, 361, 8453888);
    await drawLine(354, 361, 383, 353, 2162432);
    await drawLine(383, 353, 415, 330, 65344);
    await drawLine(415, 330, 419, 333, 65439);
    await drawLine(419, 333, 437, 354, 65535);
    await drawLine(437, 354, 445, 349, 40959);
    await drawLine(445, 349, 422, 324, 16639);
    await drawLine(422, 324, 459, 285, 2097407);
    await drawLine(459, 285, 464, 251, 8323327);
    await drawLine(464, 251, 438, 203, 14614783);
    await drawLine(438, 203, 373, 168, 16711871);
    await drawLine(373, 168, 358, 167, 16711776);
}

main();
