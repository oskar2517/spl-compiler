const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(306, 108, 283, 118, 16711680);
    await drawLine(283, 118, 245, 170, 16731392);
    await drawLine(245, 170, 255, 228, 16750848);
    await drawLine(255, 228, 294, 278, 16770304);
    await drawLine(294, 278, 327, 291, 13434624);
    await drawLine(327, 291, 347, 288, 8453888);
    await drawLine(347, 288, 389, 255, 3407616);
    await drawLine(389, 255, 397, 261, 65305);
    await drawLine(397, 261, 394, 257, 65382);
    await drawLine(394, 257, 394, 256, 65459);
    await drawLine(394, 256, 412, 271, 65535);
    await drawLine(412, 271, 416, 271, 45823);
    await drawLine(416, 271, 417, 266, 26367);
    await drawLine(417, 266, 398, 243, 6655);
    await drawLine(398, 243, 400, 239, 3342591);
    await drawLine(400, 239, 423, 202, 8323327);
    await drawLine(423, 202, 423, 172, 13369599);
    await drawLine(423, 172, 409, 146, 16711910);
    await drawLine(409, 146, 355, 111, 16711833);
    await drawLine(355, 111, 320, 105, 16711756);
}

main();
