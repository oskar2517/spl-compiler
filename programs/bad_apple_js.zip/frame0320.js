const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(303, 202, 301, 206, 16711680);
    await drawLine(301, 206, 301, 211, 16731392);
    await drawLine(301, 211, 308, 224, 16750848);
    await drawLine(308, 224, 307, 229, 16770304);
    await drawLine(307, 229, 270, 254, 13434624);
    await drawLine(270, 254, 261, 287, 8453888);
    await drawLine(261, 287, 296, 357, 3407616);
    await drawLine(296, 357, 335, 380, 65305);
    await drawLine(335, 380, 359, 378, 65382);
    await drawLine(359, 378, 384, 361, 65459);
    await drawLine(384, 361, 404, 357, 65535);
    await drawLine(404, 357, 422, 340, 45823);
    await drawLine(422, 340, 425, 267, 26367);
    await drawLine(425, 267, 399, 219, 6655);
    await drawLine(399, 219, 382, 209, 3342591);
    await drawLine(382, 209, 368, 207, 8323327);
    await drawLine(368, 207, 329, 216, 13369599);
    await drawLine(329, 216, 320, 220, 16711910);
    await drawLine(320, 220, 315, 220, 16711833);
    await drawLine(315, 220, 307, 203, 16711756);
}

main();
