const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(354, 247, 297, 276, 16711680);
    await drawLine(297, 276, 268, 322, 16732416);
    await drawLine(268, 322, 268, 347, 16752896);
    await drawLine(268, 347, 277, 365, 16773632);
    await drawLine(277, 365, 285, 371, 12386048);
    await drawLine(285, 371, 288, 375, 7077632);
    await drawLine(288, 375, 297, 398, 1834752);
    await drawLine(297, 398, 327, 414, 65334);
    await drawLine(327, 414, 390, 405, 65414);
    await drawLine(390, 405, 427, 379, 65495);
    await drawLine(427, 379, 437, 357, 55295);
    await drawLine(437, 357, 420, 295, 34559);
    await drawLine(420, 295, 423, 291, 14079);
    await drawLine(423, 291, 432, 288, 1769727);
    await drawLine(432, 288, 431, 284, 7012607);
    await drawLine(431, 284, 427, 283, 12321023);
    await drawLine(427, 283, 413, 287, 16711922);
    await drawLine(413, 287, 378, 251, 16711841);
    await drawLine(378, 251, 359, 246, 16711761);
}

main();
