const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(353, 246, 334, 253, 16711680);
    await drawLine(334, 253, 329, 252, 16730368);
    await drawLine(329, 252, 301, 262, 16749056);
    await drawLine(301, 262, 279, 300, 16767744);
    await drawLine(279, 300, 282, 364, 14417664);
    await drawLine(282, 364, 299, 394, 9633536);
    await drawLine(299, 394, 316, 404, 4849408);
    await drawLine(316, 404, 355, 400, 65280);
    await drawLine(355, 400, 365, 396, 65353);
    await drawLine(365, 396, 370, 396, 65426);
    await drawLine(370, 396, 371, 400, 65499);
    await drawLine(371, 400, 376, 404, 56319);
    await drawLine(376, 404, 380, 424, 37631);
    await drawLine(380, 424, 384, 423, 18943);
    await drawLine(384, 423, 381, 393, 255);
    await drawLine(381, 393, 383, 389, 4784383);
    await drawLine(383, 389, 423, 370, 9568511);
    await drawLine(423, 370, 434, 353, 14352639);
    await drawLine(434, 353, 427, 300, 16711899);
    await drawLine(427, 300, 385, 251, 16711826);
    await drawLine(385, 251, 361, 244, 16711753);
}

main();
