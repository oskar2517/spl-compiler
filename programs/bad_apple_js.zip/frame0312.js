const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(340, 251, 316, 268, 16711680);
    await drawLine(316, 268, 297, 276, 16728832);
    await drawLine(297, 276, 277, 303, 16745728);
    await drawLine(277, 303, 283, 367, 16762880);
    await drawLine(283, 367, 311, 408, 16056064);
    await drawLine(311, 408, 333, 419, 11665152);
    await drawLine(333, 419, 367, 412, 7339776);
    await drawLine(367, 412, 387, 398, 2948864);
    await drawLine(387, 398, 392, 397, 65302);
    await drawLine(392, 397, 392, 401, 65369);
    await drawLine(392, 401, 394, 405, 65435);
    await drawLine(394, 405, 396, 405, 65502);
    await drawLine(396, 405, 400, 407, 57087);
    await drawLine(400, 407, 404, 416, 39935);
    await drawLine(404, 416, 407, 417, 23039);
    await drawLine(407, 417, 409, 413, 5887);
    await drawLine(409, 413, 400, 390, 2883839);
    await drawLine(400, 390, 402, 386, 7274751);
    await drawLine(402, 386, 434, 355, 11600127);
    await drawLine(434, 355, 438, 325, 15991039);
    await drawLine(438, 325, 401, 273, 16711880);
    await drawLine(401, 273, 353, 249, 16711813);
    await drawLine(353, 249, 348, 248, 16711747);
}

main();
