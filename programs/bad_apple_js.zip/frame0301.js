const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(304, 80, 286, 88, 16711680);
    await drawLine(286, 88, 257, 134, 16744448);
    await drawLine(257, 134, 257, 183, 16776960);
    await drawLine(257, 183, 272, 209, 8453888);
    await drawLine(272, 209, 317, 229, 65280);
    await drawLine(317, 229, 362, 209, 65408);
    await drawLine(362, 209, 389, 168, 65535);
    await drawLine(389, 168, 391, 138, 32767);
    await drawLine(391, 138, 372, 98, 255);
    await drawLine(372, 98, 326, 79, 8323327);
    await drawLine(326, 79, 321, 79, 16711935);
    await drawLine(321, 79, 317, 78, 16711808);
}

main();
