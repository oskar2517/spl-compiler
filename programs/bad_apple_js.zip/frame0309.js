const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(346, 219, 284, 258, 16711680);
    await drawLine(284, 258, 268, 289, 16733440);
    await drawLine(268, 289, 271, 318, 16755200);
    await drawLine(271, 318, 294, 350, 16776960);
    await drawLine(294, 350, 308, 357, 11206400);
    await drawLine(308, 357, 311, 360, 5635840);
    await drawLine(311, 360, 298, 376, 65280);
    await drawLine(298, 376, 299, 380, 65365);
    await drawLine(299, 380, 303, 379, 65450);
    await drawLine(303, 379, 317, 364, 65535);
    await drawLine(317, 364, 333, 374, 43775);
    await drawLine(333, 374, 378, 375, 22015);
    await drawLine(378, 375, 406, 356, 255);
    await drawLine(406, 356, 426, 300, 5570815);
    await drawLine(426, 300, 420, 256, 11141375);
    await drawLine(420, 256, 411, 244, 16711935);
    await drawLine(411, 244, 375, 219, 16711850);
    await drawLine(375, 219, 360, 217, 16711765);
}

main();
