const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(333, 128, 309, 136, 16711680);
    await drawLine(309, 136, 251, 196, 16727296);
    await drawLine(251, 196, 246, 220, 16742912);
    await drawLine(246, 220, 254, 243, 16758784);
    await drawLine(254, 243, 287, 274, 16774400);
    await drawLine(287, 274, 289, 277, 13434624);
    await drawLine(289, 277, 278, 288, 9436928);
    await drawLine(278, 288, 279, 292, 5439232);
    await drawLine(279, 292, 282, 292, 1376000);
    await drawLine(282, 292, 273, 294, 65321);
    await drawLine(273, 294, 269, 297, 65382);
    await drawLine(269, 297, 274, 299, 65443);
    await drawLine(274, 299, 276, 302, 65504);
    await drawLine(276, 302, 281, 303, 57599);
    await drawLine(281, 303, 298, 285, 41983);
    await drawLine(298, 285, 302, 285, 26367);
    await drawLine(302, 285, 331, 304, 10751);
    await drawLine(331, 304, 360, 306, 1310975);
    await drawLine(360, 306, 379, 298, 5374207);
    await drawLine(379, 298, 422, 232, 9371903);
    await drawLine(422, 232, 421, 182, 13369599);
    await drawLine(421, 182, 408, 161, 16711925);
    await drawLine(408, 161, 378, 145, 16711864);
    await drawLine(378, 145, 354, 127, 16711802);
    await drawLine(354, 127, 344, 126, 16711741);
}

main();
