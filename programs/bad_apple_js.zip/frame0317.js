const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(335, 242, 298, 266, 16711680);
    await drawLine(298, 266, 269, 323, 16731392);
    await drawLine(269, 323, 271, 358, 16750848);
    await drawLine(271, 358, 283, 374, 16770304);
    await drawLine(283, 374, 299, 384, 13434624);
    await drawLine(299, 384, 315, 404, 8453888);
    await drawLine(315, 404, 338, 413, 3407616);
    await drawLine(338, 413, 367, 409, 65305);
    await drawLine(367, 409, 428, 366, 65382);
    await drawLine(428, 366, 439, 334, 65459);
    await drawLine(439, 334, 438, 319, 65535);
    await drawLine(438, 319, 408, 274, 45823);
    await drawLine(408, 274, 404, 271, 26367);
    await drawLine(404, 271, 405, 267, 6655);
    await drawLine(405, 267, 413, 261, 3342591);
    await drawLine(413, 261, 415, 257, 8323327);
    await drawLine(415, 257, 411, 255, 13369599);
    await drawLine(411, 255, 395, 265, 16711910);
    await drawLine(395, 265, 357, 242, 16711833);
    await drawLine(357, 242, 342, 240, 16711756);
}

main();
