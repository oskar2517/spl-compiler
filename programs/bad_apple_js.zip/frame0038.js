const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(0, 240, 0, 480, 16711680);
    await drawLine(0, 480, 640, 480, 16726272);
    await drawLine(640, 480, 638, 395, 16740608);
    await drawLine(638, 395, 634, 386, 16755200);
    await drawLine(634, 386, 555, 317, 16769792);
    await drawLine(555, 317, 567, 264, 14941952);
    await drawLine(567, 264, 580, 307, 11206400);
    await drawLine(580, 307, 583, 310, 7470848);
    await drawLine(583, 310, 577, 2, 3800832);
    await drawLine(577, 2, 574, -(1), 65280);
    await drawLine(574, -(1), 464, -(1), 65337);
    await drawLine(464, -(1), 459, 0, 65393);
    await drawLine(459, 0, 179, -(1), 65450);
    await drawLine(179, -(1), 174, 0, 65507);
    await drawLine(174, 0, 4, 0, 58367);
    await drawLine(4, 0, 0, 0, 43775);
    await drawLine(0, 0, 0, 235, 29183);
    await drawLine(513, 230, 514, 235, 14847);
    await drawLine(514, 235, 512, 238, 255);
    await drawLine(512, 238, 508, 237, 3735807);
    await drawLine(508, 237, 507, 232, 7405823);
    await drawLine(507, 232, 509, 222, 11141375);
    await drawLine(509, 222, 511, 225, 14876927);
    await drawLine(578, 1, 638, 154, 16711907);
    await drawLine(638, 154, 640, 155, 16711850);
    await drawLine(640, 155, 640, 0, 16711793);
    await drawLine(640, 0, 610, 0, 16711737);
}

main();
