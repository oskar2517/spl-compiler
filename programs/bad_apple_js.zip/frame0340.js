const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(334, 143, 308, 157, 16711680);
    await drawLine(308, 157, 273, 205, 16744448);
    await drawLine(273, 205, 273, 279, 16776960);
    await drawLine(273, 279, 286, 301, 8453888);
    await drawLine(286, 301, 316, 319, 65280);
    await drawLine(316, 319, 384, 328, 65408);
    await drawLine(384, 328, 433, 306, 65535);
    await drawLine(433, 306, 450, 281, 32767);
    await drawLine(450, 281, 461, 218, 255);
    await drawLine(461, 218, 430, 174, 8323327);
    await drawLine(430, 174, 373, 144, 16711935);
    await drawLine(373, 144, 353, 141, 16711808);
}

main();
