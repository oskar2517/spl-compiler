const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(0, 11, 0, 20, 16711680);
    await drawLine(0, 20, 2, 25, 16723200);
    await drawLine(2, 25, 614, 57, 16734720);
    await drawLine(614, 57, 618, 59, 16746240);
    await drawLine(618, 59, 609, 62, 16757760);
    await drawLine(609, 62, 582, 75, 16769280);
    await drawLine(582, 75, 573, 87, 15793920);
    await drawLine(573, 87, 572, 102, 12844800);
    await drawLine(572, 102, 580, 120, 9895680);
    await drawLine(580, 120, 587, 127, 6946560);
    await drawLine(587, 127, 632, 133, 3997440);
    await drawLine(632, 133, 636, 131, 1048320);
    await drawLine(636, 131, 639, 128, 65310);
    await drawLine(639, 128, 637, 58, 65355);
    await drawLine(637, 58, 639, 54, 65400);
    await drawLine(639, 54, 639, -(1), 65445);
    await drawLine(639, -(1), 499, -(1), 65490);
    await drawLine(499, -(1), 494, 0, 65535);
    await drawLine(494, 0, 179, -(1), 54015);
    await drawLine(179, -(1), 174, 0, 42495);
    await drawLine(174, 0, 4, 0, 30975);
    await drawLine(4, 0, 0, 0, 19455);
    await drawLine(0, 0, 0, 10, 7935);
    await drawLine(348, 177, 278, 200, 983295);
    await drawLine(278, 200, 270, 207, 3932415);
    await drawLine(270, 207, 259, 264, 6881535);
    await drawLine(259, 264, 279, 325, 9830655);
    await drawLine(279, 325, 336, 364, 12779775);
    await drawLine(336, 364, 370, 362, 15728895);
    await drawLine(370, 362, 418, 327, 16711905);
    await drawLine(418, 327, 443, 257, 16711860);
    await drawLine(443, 257, 434, 218, 16711815);
    await drawLine(434, 218, 411, 193, 16711770);
    await drawLine(396, 190, 354, 176, 16711725);
}

main();
