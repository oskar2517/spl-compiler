const printc = jsContext.printc;
const exit = jsContext.exit;
const setPixel = jsContext.setPixel;
const readi = jsContext.readi;
const drawCircle = jsContext.drawCircle;
const readc = jsContext.readc;
const printi = jsContext.printi;
const time = jsContext.time;
const drawLine = jsContext.drawLine;
const clearAll = jsContext.clearAll;

async function main() {
    await drawLine(326, 181, 281, 226, 16711680);
    await drawLine(281, 226, 276, 226, 16732416);
    await drawLine(276, 226, 275, 223, 16752896);
    await drawLine(275, 223, 261, 217, 16773632);
    await drawLine(261, 217, 257, 219, 12386048);
    await drawLine(257, 219, 258, 224, 7077632);
    await drawLine(258, 224, 277, 239, 1834752);
    await drawLine(277, 239, 260, 280, 65334);
    await drawLine(260, 280, 264, 304, 65414);
    await drawLine(264, 304, 294, 337, 65495);
    await drawLine(294, 337, 350, 356, 55295);
    await drawLine(350, 356, 389, 348, 34559);
    await drawLine(389, 348, 408, 326, 14079);
    await drawLine(408, 326, 415, 307, 1769727);
    await drawLine(415, 307, 430, 288, 7012607);
    await drawLine(430, 288, 433, 258, 12321023);
    await drawLine(433, 258, 389, 199, 16711922);
    await drawLine(389, 199, 348, 180, 16711841);
    await drawLine(348, 180, 338, 179, 16711761);
}

main();
